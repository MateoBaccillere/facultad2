package modelo.vehiculo.abm;

import modelo.vehiculo.Auto;
import modelo.vehiculo.Moto;
import modelo.vehiculo.Vehiculo;
import repositorio.RepositorioDatos;

public class ABMAutoImpl implements IAbmVehiculo {

	@Override
	public boolean cargarVehiculoImpl(Vehiculo vehiculo) {
		if (RepositorioDatos.indice < RepositorioDatos.TAMANIO_ARREGLO) {
			if (vehiculo instanceof Auto) {
				Auto auto = (Auto) vehiculo;
				if (validarAuto(auto)) {
					if (existeAuto(auto) == -1) {
						RepositorioDatos.vehiculos[RepositorioDatos.indice] = vehiculo;
						RepositorioDatos.indice++;
						return true;
					} else {
						System.out.println("El auto ingresado ya existe");
					}
				} else {
					System.out.println("Faltan cargar datos");
				}
			} else {
				System.out.println("El vehiculo no es un auto");
			}
		} else {
			System.out.println("Se supero la capacidad del arreglo de vehiculos");
		}
		return false;
	}

	@Override
	public boolean modificarVehiculoImpl(Vehiculo vehiculo) {

		Auto auto = (Auto) vehiculo;
		if (validarAuto(auto)) {
			int i = existeAuto(auto);
			if (i != -1) {
				RepositorioDatos.vehiculos[i] = vehiculo;
				return true;
			} else
				System.out.println("El auto ingresado no existe");
		} else
			System.out.println("Faltan cargar datos");

		return false;
	}

	@Override
	public void eliminarVehiculoImpl(Vehiculo vehiculo) {
		Auto auto = (Auto) vehiculo;
		int i = existeAuto(auto);
		if (i != -1) {
			RepositorioDatos.vehiculos[i] = null;
		} else {
			System.out.println("No se encontro el auto que quiere eliminar");
		}
	}

	private boolean validarAuto(Auto auto) {
		if (auto == null)
			return false;
		else {
			if (auto.getMarca().equals(""))
				return false;
			if (auto.getModelo().equals(""))
				return false;
			if (auto.getTipoCombustible().equals(""))
				return false;
			if (auto.getCantPuerta() == 0)
				return false;
		}
		return true;
	}

	private int existeAuto(Auto auto) {
		for (int i = 0; i < RepositorioDatos.vehiculos.length; i++) {
			if (RepositorioDatos.vehiculos[i] instanceof Moto) {
				Auto a = (Auto) RepositorioDatos.vehiculos[i];
				if (a != null && auto.getPatente().equals(a.getPatente()))
					return i;
			}
		}
		return -1;
	}


	@Override
	public void mostrarVehiculoImpl() {
		for (int i = 0; i < RepositorioDatos.vehiculos.length; i++) {
			if (RepositorioDatos.vehiculos[i] instanceof Auto) {
				Auto auto = (Auto) RepositorioDatos.vehiculos[i];
				if (auto != null) {
					System.out.println(auto);

				}
			}
		}
	}
}
