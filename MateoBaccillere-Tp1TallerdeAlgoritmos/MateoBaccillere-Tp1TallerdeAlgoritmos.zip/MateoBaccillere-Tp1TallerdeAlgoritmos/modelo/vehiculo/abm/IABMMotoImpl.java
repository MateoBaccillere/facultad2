package modelo.vehiculo.abm;

import modelo.vehiculo.Moto;
import modelo.vehiculo.Vehiculo;
import repositorio.RepositorioDatos;

public class IABMMotoImpl implements IAbmVehiculo {


	//El Override se utiliza cuando hay una sobrecarga de métodos
	@Override
	public boolean cargarVehiculoImpl(Vehiculo vehiculo) {
		if (RepositorioDatos.indice < RepositorioDatos.TAMANIO_ARREGLO) {
			if (vehiculo instanceof Moto) {
				Moto moto = (Moto) vehiculo;
				if (validarMoto(moto)) {
					if (existeMoto(moto) == -1) {
						RepositorioDatos.vehiculos[RepositorioDatos.indice] = vehiculo;
						RepositorioDatos.indice++;
						return true;
					} else {
						System.out.println("La moto ingresada ya esta cargada");
					}
				} else {
					System.out.println("Faltan cargar datos en el arreglo");
				}
			} else {
				System.out.println("El vehiculo no es una moto");
			}
		} else {
			System.out.println("Se supero la capacidad del arreglo de vehiculos");
		}
		return false;
	}

	@Override
	public boolean modificarVehiculoImpl(Vehiculo vehiculo) {
		Moto moto = (Moto) vehiculo;
		if (validarMoto(moto)) {
			int i = existeMoto(moto);
			if (i != -1) {
				RepositorioDatos.vehiculos[i] = vehiculo;
				return true;
			} else
				System.out.println("La moto ingresada no existe en el arreglo de vehiculos");
		} else
			System.out.println("Faltan cargar datos al arreglo");

		return false;
	}

	@Override
	public void eliminarVehiculoImpl(Vehiculo vehiculo) {
		Moto moto = (Moto) vehiculo;
		int i = existeMoto(moto);
		if (i != -1) {
			RepositorioDatos.vehiculos[i] = null;
		} else {
			System.out.println("No se encontro la moto que quiere eliminar");
		}
	}


	private boolean validarMoto(Moto moto) {
		if (moto == null)
			return false;
		else {
			if (moto.getMarca().equals(""))
				return false;
			if (moto.getModelo().equals(""))
				return false;
			if (moto.getTipoCombustible().equals(""))
				return false;
			if (moto.getCilindrado() > 3000)
				return false;
		}
		return true;
	}

	private int existeMoto(Moto moto) {
		for (int i = 0; i < RepositorioDatos.vehiculos.length; i++) {
			if (RepositorioDatos.vehiculos[i] instanceof Moto) {
				Moto a = (Moto) RepositorioDatos.vehiculos[i];
				if (a != null && moto.getPatente().equals(a.getPatente()))
					return i;
			}
		}
		return -1;
	}

	@Override
	public void mostrarVehiculoImpl() {
		for (int i = 0; i < RepositorioDatos.vehiculos.length; i++) {
			if (RepositorioDatos.vehiculos[i] instanceof Moto) {
				Moto moto = (Moto) RepositorioDatos.vehiculos[i];
				if (moto != null) {
					System.out.println(moto);

				}
			}
		}
	}
}
